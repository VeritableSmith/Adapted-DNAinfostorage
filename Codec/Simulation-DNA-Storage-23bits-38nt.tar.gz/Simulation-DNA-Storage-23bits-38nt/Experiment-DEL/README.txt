Experiment: 
Storing 23 bits (addresses+data) in template DNA sequences of length 38-nt


FOLDERS

- Bit-Sequences
  x = 5, 10, 15, 20, 25, 30, 35, 40, 45, ..., 595, 600. 

  CONTAINS files: bits_x.txt 

  FILE FORMAT
  Each row of bits_x.txt contains a random sequence of 23 bits. 



- Encoded-DNA-Sequences-With-DEL
  x = 5, 10, 15, 20, 25, 30, 35, 40, 45, ..., 595, 600.
  y = A, B, C, D, E, F, G, H, I, J.
  y represents up to 10 different, diverse DNA strands in simulation. 

  CONTAINS files: encoded_DNA_sequences_with_DEL_y_x.txt 
  
  FILE FORMAT
  Each row of encoded_DNA_sequences_with_DEL_y_x.txt contains a sequence
  of nucleotides of variable length. This sequence is determined by encoding
  the bit sequence in bits_x.txt into a sequence of nucleotides which is then
  simulated through a DNA channel with deletion rate per nucleotide given
  by p_del = x/1000. Each of 10 different, diverse DNA strands are simulated,
  represented by y = A, B, C, D, E, F, G, H, I, J.  


- MAP-Decoded-DNA-Sequences
  x = 5, 10, 15, 20, 25, 30, 35, 40, 45, ..., 595, 600.
  y = A, B, C, D, E, F, G, H, I, J.
  z = 0, 1, 2, 3, 4, 5. 
  f(z) = 2z (if z > 0)
  f(z) = 1  (if z = 0) 
  
  CONTAINS files: map_decoded_DNA_sequences_z_x.txt 

  FILE FORMAT
  Each row of map_decoded_DNA_sequences_z_x.txt contains a sequence of 
  nucleotides of length 38-nt. This sequence is the result of MAP decoding
  of up to f(z) simulated, diverse DNA strands available in the 
  files encoded_DNA_sequences_with_DEL_y_x.txt. 



- Decoded-Bit-Sequences
  x = 5, 10, 15, 20, 25, 30, 35, 40, 45, ..., 595, 600.
  y = A, B, C, D, E, F, G, H, I, J.
  z = 0, 1, 2, 3, 4, 5. 
  f(z) = 2z (if z > 0)
  f(z) = 1  (if z = 0) 

  CONTAINS files: decoded_bits_z_x.txt 

  FILE FORMAT
  Each row of decoded_bits_z_x.txt contains the result of decoding the 38-nt
  nucleotide sequence in map_decoded_DNA_sequences_z_x.txt into a bit sequence
  of length 23-bits. A final column is appended and represents the output of 
  a BCH decoder for which -1 means decoding error, and a non-negative integer
  means the number of bit errors corrected by the BCH code. 