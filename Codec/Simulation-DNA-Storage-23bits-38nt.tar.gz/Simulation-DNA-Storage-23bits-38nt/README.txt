Experiment: 
Storing 23 bits (addresses+data) in template DNA sequences of length 38-nt

FOLDERS

- Experiment-DEL
  Template DNA sequences of length 38-nt are simulated through a DNA channel
  to yield 10 diverse DNA strands containing varying amounts of deletions. 

- Experiment-DEL-INS-SUB
  Template DNA sequences of length 38-nt are simulated through a DNA channel
  to yield 10 diverse DNA strands which contain varying amounts of deletions, 
  insertions, and substitutions.   